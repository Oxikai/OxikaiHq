if (2 > 1):
    print("still new keywords")
wait = input('Press enter to continue... ')