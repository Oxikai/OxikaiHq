using static System.Console;
namespace CS_Program {
    class Program {
        static void Main(str[], args) {
            WriteLine("hello, world!");
str wait = ReadLine("Press enter to continue... ")            }
        }
    }