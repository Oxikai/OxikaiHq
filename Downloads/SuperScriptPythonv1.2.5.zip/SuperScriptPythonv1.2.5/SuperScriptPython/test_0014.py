if (3 >= 3):
    print("hello boiiiiiiis")
wait = input('Press enter to continue... ')