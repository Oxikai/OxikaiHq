if (1 > 1):
    print("h")
input('Press enter to continue... ')    print("hi else write bye")
input('Press enter to continue... ')