if (36 < 57){
    console.log("ok then ',:)")
    }
var wait = window.prompt('Press enter to continue... ');