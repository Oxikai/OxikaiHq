using static System.Console;
namespace CS_Program {
    class Program {
        static void Main(string[] args) {
            WriteLine("hello, world!");
            str wait = ReadLine("Press enter to continue... ")
            }
        }
    }