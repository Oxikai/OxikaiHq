if (3 > 2):
    print("three is bigger than two")
wait = input('Press enter to continue... ')