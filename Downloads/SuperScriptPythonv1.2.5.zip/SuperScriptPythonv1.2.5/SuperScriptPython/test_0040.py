print("Hello, World! I can WRITE CAPITAL LETTERS NOOOOOW!!!!")
wait = input('Press enter to continue... ')