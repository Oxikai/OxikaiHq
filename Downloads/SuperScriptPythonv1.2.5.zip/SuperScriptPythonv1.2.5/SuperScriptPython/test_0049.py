if (1 > 2):
    print("nope ")
    print("write sure")
input('Press enter to continue... ')