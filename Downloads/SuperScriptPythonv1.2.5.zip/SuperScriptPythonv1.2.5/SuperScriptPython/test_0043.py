if (9874 > 6):
    if (6 < 12):
        print("there's a fire in malaysia!!!!!!")
input('Press enter to continue... ')