if (1 >= 0):
    print("1 >= 0")
wait = input('Press enter to continue... ')