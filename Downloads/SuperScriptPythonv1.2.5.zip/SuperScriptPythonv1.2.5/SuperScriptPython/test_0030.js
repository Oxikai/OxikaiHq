console.log("hello")
var wait = window.prompt('Press enter to continue... ');