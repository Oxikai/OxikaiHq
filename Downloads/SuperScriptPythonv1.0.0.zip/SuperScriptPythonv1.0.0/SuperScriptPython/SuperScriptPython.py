import os

print ("What would you like to program today?")
command = input()
args = command.lower().split(" ")


def commandProcess(args):
    tab = ""
    intTab = 0
    bracket = 0
    endIf = 0
    file = open("CPUCode.txt", "w")
    fileType = input("What language is it in? *Type python, C#, VBScript, Javascript, or HTML* -> ").lower()
    if (fileType == "python"):
        extension = "py"
        writePython(args, intTab, tab, file)
    elif (fileType == "c#"):
        extension = "cs"
        intTab = 3
        file.write("using static System.Console;\n\nnamespace CS_Program {\n    class Program {\n        static void Main(string[] args) {\n")
        writeCS(args, intTab, tab, file, bracket)
    elif (fileType == "vbscript"):
        extension = "vbs"
        file.write("Title = \"VBScript File\"\n")
        writeVBS(args, intTab, tab, file, endIf)
    elif (fileType == "javascript"):
        extension = "js"
        writeJS(args, intTab, tab, file, bracket)
    elif (fileType == "html"):
        extension = "html"
        if (args[0] == "if"):
            print ("HTML5 does not contain any if statements")
            try:
                exit()
            except:
                args = ""
                print("")
        file.write("<!DOCTYPE html>\n    <head>\n        <title>New Html File</title>\n    </head>\n    <body>\n")
        intTab = 2
        writeHTML(args, intTab, tab, file)
    elif (fileType == "css"):
        extension = "css"
        writeCSS(args, intTab, tab, file)
    else:
        print("I'm sorry, my programming does not contain that language")

def writePython(args, intTab, tab, file):
    extension = "py"
    endClause = "wait = input('Press enter to continue... ')"
    if (intTab == 0):
        tab = ""
    elif (intTab == 1):
        tab = "    "
    elif (intTab == 2):
        tab = "        "
    
    if(args[0] == "then"):
        args.pop(0)

    if (args[0] == "write"):
        args.pop(0)
        command = " ".join(args)
        file.write("{}print(\"{}\")\n{}".format(tab, command, endClause))
        args = ""
        
    elif (args[0] == "if"):
        a = args[1]
        if((args[3] == "greater" or args[3] == "bigger") and args[4] == "than"):
            b = ">"
        elif((args[3] == "less" or "smaller") and args[4] == "than"):
            b = "<"
        elif(args[3] == "equal" and args[4] == "to"):
            b = "=="
        elif(args[3] == "equals"):
            b = "=="

        if(args[5] == "or" and args[6] == "equal" and args[7] == "to"):
            b = str(b + "=")
            args.pop(5)
            args.pop(5)
            args.pop(5)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        c = args[0]
        args.pop(0)
        file.write("{}if ({} {} {}):\n".format(tab, a, b, c))
        intTab +=1
        writePython(args, intTab, tab, file)
        
    if (args != ""):
        writePython(args, intTab, tab, file)
    else:
        file.close()

    name = input("What would you like to call your program? -> ")
    endMessages(name, extension)

def writeCS(args, intTab, tab, file, bracket):
    extension = "cs"
    endClause = "            str wait = ReadLine(\"Press enter to continue... \");\n"

    if (intTab == 0):
        tab = ""
    elif (intTab == 1):
        tab = "    "
    elif (intTab == 2):
        tab = "        "
    elif (intTab == 3):
        tab = "            "
    elif (intTab == 4):
        tab = "                "
    
    if(args[0] == "then"):
        args.pop(0)

    if (args[0] == "write"):
        args.pop(0)
        command = " ".join(args)
        file.write("{}WriteLine(\"{}\");\n{}".format(tab, command, endClause))
        args = ""
        
    elif (args[0] == "if"):
        a = args[1]
        if((args[3] == "greater" or args[3] == "bigger") and args[4] == "than"):
            b = ">"
        elif((args[3] == "less" or "smaller") and args[4] == "than"):
            b = "<"
        elif(args[3] == "equal" and args[4] == "to"):
            b = "=="
        elif(args[3] == "equals"):
            b = "=="

        if(args[5] == "or" and args[6] == "equal" and args[7] == "to"):
            b = str(b + "=")
            args.pop(5)
            args.pop(5)
            args.pop(5)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        c = args[0]
        args.pop(0)
        file.write("{}if ({} {} {}){}\n".format(tab, a, b, c, "{"))
        intTab +=1
        bracket += 1
        writeCS(args, intTab, tab, file, bracket)
        
    if (args != ""):
        writeCS(args, intTab, tab, file, bracket)
    else:
        if (bracket > 0):
            while (bracket > 0):
                file.write("{}{}\n".format(tab, "}"))
                bracket -= 1
        file.write("            }\n        }\n    }")
        file.close()

    name = input("What would you like to call your program? -> ")
    endMessages(name, extension)

def writeVBS(args, intTab, tab, file, endIf):
    extension = "vbs"
    if (intTab == 0):
        tab = ""
    elif (intTab == 1):
        tab = "    "
    elif (intTab == 2):
        tab = "        "
    
    if(args[0] == "then"):
        args.pop(0)

    if (args[0] == "write"):
        args.pop(0)
        command = " ".join(args)
        file.write("{}msgBox \"{}\"\n".format(tab, command))
        args = ""
        
    elif (args[0] == "if"):
        a = args[1]
        if((args[3] == "greater" or args[3] == "bigger") and args[4] == "than"):
            b = ">"
        elif((args[3] == "less" or "smaller") and args[4] == "than"):
            b = "<"
        elif(args[3] == "equal" and args[4] == "to"):
            b = "=="
        elif(args[3] == "equals"):
            b = "=="

        if(args[5] == "or" and args[6] == "equal" and args[7] == "to"):
            b = str(b + "=")
            args.pop(5)
            args.pop(5)
            args.pop(5)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        c = args[0]
        args.pop(0)
        file.write("{}if ({} {} {}) Then\n".format(tab, a, b, c))
        intTab +=1
        endIf += 1
        writeVBS(args, intTab, tab, file, endIf)
        
    if (args != ""):
        writeVBS(args, intTab, tab, file, endIf)
    else:
        if (endIf > 0):
            while (endIf > 0):
                endIf -= 1
                file.write("End If\n")
        file.close()

    name = input("What would you like to call your program? -> ")
    endMessages(name, extension)

def writeJS(args, intTab, tab, file, bracket):
    extension = "js"
    endClause = "var wait = window.prompt('Press enter to continue... ');"
    if (intTab == 0):
        tab = ""
    elif (intTab == 1):
        tab = "    "
    elif (intTab == 2):
        tab = "        "
    
    if(args[0] == "then"):
        args.pop(0)

    if (args[0] == "write"):
        args.pop(0)
        command = " ".join(args)
        file.write("{}console.log(\"{}\")\n".format(tab, command))
        args = ""
        
    elif (args[0] == "if"):
        a = args[1]
        if((args[3] == "greater" or args[3] == "bigger") and args[4] == "than"):
            b = ">"
        elif((args[3] == "less" or "smaller") and args[4] == "than"):
            b = "<"
        elif(args[3] == "equal" and args[4] == "to"):
            b = "=="
        elif(args[3] == "equals"):
            b = "=="

        if(args[5] == "or" and args[6] == "equal" and args[7] == "to"):
            b = str(b + "=")
            args.pop(5)
            args.pop(5)
            args.pop(5)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        args.pop(0)
        c = args[0]
        args.pop(0)
        file.write("{}if ({} {} {}){}\n".format(tab, a, b, c, "{"))
        intTab += 1
        bracket += 1
        writeJS(args, intTab, tab, file, bracket)
        
    if (args != ""):
        writeJS(args, intTab, tab, file, bracket)
    else:
        if (bracket > 0):
            while (bracket > 0):
                file.write("{}{}\n".format(tab, "}"))
                bracket -= 1
        file.write(endClause)
        file.close()

    name = input("What would you like to call your program? -> ")
    endMessages(name, extension)

def writeHTML(args, intTab, tab, file):
    extension = "html"
    if (args[0] == "write"):
        args.pop(0)
        if (args[0] == "a"):
            args.pop(0)
            if (args[0] == "heading" and args[1] == "that" and (args[2] == "says" or args[2] == "says:")):
                args.pop(0)
                args.pop(0)
                args.pop(0)
                command = " ".join(args)
                file.write("<h1>{}</h1>\n".format(command))
                args = ""
            elif (args[0] == "paragraph" and args[1] == "that" and (args[2] == "says" or args[2] == "says:")):
                args.pop(0)
                args.pop(0)
                args.pop(0)
                command = " ".join(args)
                file.write("<p>{}</p>\n".format(command))
                args = ""

    if (args != ""):
        writeHTML(args, intTab, tab, file)
    else:
        file.write("    </body>\n</html>")
        file.close()

        name = input("What would you like to call your program? -> ")
        endMessages(name, extension)

def endMessages(name, extension):
    try:
        os.rename("CPUCode.txt", "{}.{}".format(name, extension))
    except FileNotFoundError:
        print("")
    else:
        print ("Would you like to excecute your file? (Y or N)")
        answer = input()
        if( answer == "Y"):
            os.startfile("{}.{}".format(name, extension))
        endMessages(name, extension)
        print("Successfully wrote your code, the file name is {}.{}".format(name,extension))

commandProcess(args)