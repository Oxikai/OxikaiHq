if (1 < 2):
    print("eyyyyyyyyyyyyyyyyy")
wait = input('Press enter to continue... ')