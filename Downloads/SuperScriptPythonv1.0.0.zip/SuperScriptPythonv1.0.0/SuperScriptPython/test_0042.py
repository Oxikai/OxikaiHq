print("i got a new cursor(s) babyyyyyyyyyyyyyyyyyyyyyy")
wait = input('Press enter to continue... ')