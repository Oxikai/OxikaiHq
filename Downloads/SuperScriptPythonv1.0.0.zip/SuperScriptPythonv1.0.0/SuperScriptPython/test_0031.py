if (1 > 2):
    print("new keywords")
wait = input('Press enter to continue... ')