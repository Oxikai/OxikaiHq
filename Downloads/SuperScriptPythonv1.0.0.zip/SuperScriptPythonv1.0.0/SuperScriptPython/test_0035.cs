using static System.Console;

namespace CS_Program {
    class Program {
        static void Main(string[] args) {
            WriteLine("a test");
            str wait = ReadLine("Press enter to continue... ");
            }
        }
    }