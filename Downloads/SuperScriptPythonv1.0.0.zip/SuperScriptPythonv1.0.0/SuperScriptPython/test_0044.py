if (1 < 2):
    if (2 < 3):
        if (3 > 1):
        print("why cruel world!")
input('Press enter to continue... ')