if (1 < 2){
    console.log("a less than operator is being used, quite the variety")
