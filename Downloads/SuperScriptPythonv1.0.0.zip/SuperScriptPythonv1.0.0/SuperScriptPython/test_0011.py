if (60 < 100):
    print("you are correct sir")
wait = input('Press enter to continue... ')