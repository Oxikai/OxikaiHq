if (1 == 2):
    else:
        print("nope")
input('Press enter to continue... ')