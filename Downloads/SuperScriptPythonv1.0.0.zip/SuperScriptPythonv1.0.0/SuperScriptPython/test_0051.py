if (500 > 2):
    print("eyyyyyyyy boiiiiii")
wait = input('Press enter to continue... ')