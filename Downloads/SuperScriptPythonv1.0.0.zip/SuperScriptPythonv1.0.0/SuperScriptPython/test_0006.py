print("hello, world!")
wait = input('Press enter to continue... ')