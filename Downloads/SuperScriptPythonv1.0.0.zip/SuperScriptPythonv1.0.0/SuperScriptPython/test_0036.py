if (1 < 2):
    print("another new keyword? holy mackeral did we get fancy or what?")
wait = input('Press enter to continue... ')