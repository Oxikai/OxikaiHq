using static System.Console;
namespace CS_Program {
    class Program {
        static void Main(string[] args) {
            if (1 == 1){
                WriteLine("aye matey");
            str wait = ReadLine("Press enter to continue... ");
                }
            }
        }
    }