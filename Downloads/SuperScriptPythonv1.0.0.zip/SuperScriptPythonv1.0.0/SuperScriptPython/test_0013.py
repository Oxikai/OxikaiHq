if (2 > 1):
    print("2 bigger 1")
wait = input('Press enter to continue... ')