﻿namespace Pong
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.player = new System.Windows.Forms.PictureBox();
            this.ball = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.cpu = new System.Windows.Forms.PictureBox();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            this.playerScore = new System.Windows.Forms.Label();
            this.cpuLabel = new System.Windows.Forms.Label();
            this.borderRight = new System.Windows.Forms.PictureBox();
            this.borderBottom = new System.Windows.Forms.PictureBox();
            this.easy = new System.Windows.Forms.Label();
            this.hard = new System.Windows.Forms.Label();
            this.insane = new System.Windows.Forms.Label();
            this.impossible = new System.Windows.Forms.Label();
            this.playAgain = new System.Windows.Forms.Label();
            this.menuButton = new System.Windows.Forms.Label();
            this.title = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Label();
            this.youSureMessage = new System.Windows.Forms.Label();
            this.Yes = new System.Windows.Forms.Label();
            this.No = new System.Windows.Forms.Label();
            this.pauseButton = new System.Windows.Forms.Label();
            this.playButton = new System.Windows.Forms.PictureBox();
            this.baby = new System.Windows.Forms.Label();
            this.arrowUp = new System.Windows.Forms.PictureBox();
            this.arrowDown = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ball2 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cpu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.borderRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.borderBottom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrowUp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrowDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball2)).BeginInit();
            this.SuspendLayout();
            // 
            // player
            // 
            this.player.BackColor = System.Drawing.Color.White;
            this.player.Location = new System.Drawing.Point(12, 186);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(27, 127);
            this.player.TabIndex = 0;
            this.player.TabStop = false;
            // 
            // ball
            // 
            this.ball.BackColor = System.Drawing.Color.White;
            this.ball.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ball.BackgroundImage")));
            this.ball.Location = new System.Drawing.Point(434, 239);
            this.ball.Name = "ball";
            this.ball.Size = new System.Drawing.Size(27, 26);
            this.ball.TabIndex = 1;
            this.ball.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(622, 233);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(0, 0);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // cpu
            // 
            this.cpu.BackColor = System.Drawing.Color.White;
            this.cpu.Location = new System.Drawing.Point(897, 230);
            this.cpu.Name = "cpu";
            this.cpu.Size = new System.Drawing.Size(27, 127);
            this.cpu.TabIndex = 3;
            this.cpu.TabStop = false;
            // 
            // gameTimer
            // 
            this.gameTimer.Enabled = true;
            this.gameTimer.Interval = 20;
            this.gameTimer.Tick += new System.EventHandler(this.timerTick);
            // 
            // playerScore
            // 
            this.playerScore.AutoSize = true;
            this.playerScore.BackColor = System.Drawing.Color.Transparent;
            this.playerScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.playerScore.ForeColor = System.Drawing.Color.Lime;
            this.playerScore.Location = new System.Drawing.Point(105, 9);
            this.playerScore.Name = "playerScore";
            this.playerScore.Size = new System.Drawing.Size(38, 26);
            this.playerScore.TabIndex = 4;
            this.playerScore.Text = "00";
            // 
            // cpuLabel
            // 
            this.cpuLabel.AutoSize = true;
            this.cpuLabel.BackColor = System.Drawing.Color.Transparent;
            this.cpuLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.cpuLabel.ForeColor = System.Drawing.Color.Red;
            this.cpuLabel.Location = new System.Drawing.Point(735, 9);
            this.cpuLabel.Name = "cpuLabel";
            this.cpuLabel.Size = new System.Drawing.Size(38, 26);
            this.cpuLabel.TabIndex = 5;
            this.cpuLabel.Text = "00";
            // 
            // borderRight
            // 
            this.borderRight.BackColor = System.Drawing.Color.Black;
            this.borderRight.Location = new System.Drawing.Point(919, 0);
            this.borderRight.Name = "borderRight";
            this.borderRight.Size = new System.Drawing.Size(249, 579);
            this.borderRight.TabIndex = 7;
            this.borderRight.TabStop = false;
            // 
            // borderBottom
            // 
            this.borderBottom.BackColor = System.Drawing.Color.Black;
            this.borderBottom.Location = new System.Drawing.Point(-6, 563);
            this.borderBottom.Name = "borderBottom";
            this.borderBottom.Size = new System.Drawing.Size(939, 154);
            this.borderBottom.TabIndex = 8;
            this.borderBottom.TabStop = false;
            // 
            // easy
            // 
            this.easy.AutoSize = true;
            this.easy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.easy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.easy.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.easy.ForeColor = System.Drawing.Color.Lime;
            this.easy.Location = new System.Drawing.Point(398, 145);
            this.easy.Name = "easy";
            this.easy.Size = new System.Drawing.Size(95, 41);
            this.easy.TabIndex = 9;
            this.easy.Text = "Easy";
            this.easy.MouseClick += new System.Windows.Forms.MouseEventHandler(this.easyGame);
            // 
            // hard
            // 
            this.hard.AutoSize = true;
            this.hard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.hard.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.hard.ForeColor = System.Drawing.Color.Yellow;
            this.hard.Location = new System.Drawing.Point(398, 195);
            this.hard.Name = "hard";
            this.hard.Size = new System.Drawing.Size(93, 41);
            this.hard.TabIndex = 10;
            this.hard.Text = "Hard";
            this.hard.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hardGame);
            // 
            // insane
            // 
            this.insane.AutoSize = true;
            this.insane.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.insane.Cursor = System.Windows.Forms.Cursors.Hand;
            this.insane.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.insane.ForeColor = System.Drawing.Color.Red;
            this.insane.Location = new System.Drawing.Point(383, 245);
            this.insane.Name = "insane";
            this.insane.Size = new System.Drawing.Size(122, 41);
            this.insane.TabIndex = 11;
            this.insane.Text = "Insane";
            this.insane.MouseClick += new System.Windows.Forms.MouseEventHandler(this.insaneGame);
            // 
            // impossible
            // 
            this.impossible.AutoSize = true;
            this.impossible.Cursor = System.Windows.Forms.Cursors.No;
            this.impossible.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.impossible.ForeColor = System.Drawing.Color.Black;
            this.impossible.Location = new System.Drawing.Point(374, 498);
            this.impossible.Name = "impossible";
            this.impossible.Size = new System.Drawing.Size(150, 20);
            this.impossible.TabIndex = 12;
            this.impossible.Text = "Basically Impossible";
            this.impossible.MouseUp += new System.Windows.Forms.MouseEventHandler(this.impossibleGame);
            // 
            // playAgain
            // 
            this.playAgain.AutoSize = true;
            this.playAgain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.playAgain.Cursor = System.Windows.Forms.Cursors.Hand;
            this.playAgain.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.playAgain.ForeColor = System.Drawing.Color.White;
            this.playAgain.Location = new System.Drawing.Point(570, 184);
            this.playAgain.Name = "playAgain";
            this.playAgain.Size = new System.Drawing.Size(235, 48);
            this.playAgain.TabIndex = 13;
            this.playAgain.Text = "Play Again?";
            this.playAgain.MouseUp += new System.Windows.Forms.MouseEventHandler(this.resetGame);
            // 
            // menuButton
            // 
            this.menuButton.AutoSize = true;
            this.menuButton.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.menuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.menuButton.ForeColor = System.Drawing.Color.White;
            this.menuButton.Location = new System.Drawing.Point(570, 267);
            this.menuButton.Name = "menuButton";
            this.menuButton.Size = new System.Drawing.Size(121, 48);
            this.menuButton.TabIndex = 14;
            this.menuButton.Text = "Menu";
            this.menuButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.menu);
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F);
            this.title.ForeColor = System.Drawing.Color.White;
            this.title.Location = new System.Drawing.Point(367, 19);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(153, 63);
            this.title.TabIndex = 15;
            this.title.Text = "Pong";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(1040, 58);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 142);
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1119, 215);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "lol";
            // 
            // exitButton
            // 
            this.exitButton.AutoSize = true;
            this.exitButton.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.exitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.exitButton.ForeColor = System.Drawing.Color.White;
            this.exitButton.Location = new System.Drawing.Point(570, 344);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(90, 48);
            this.exitButton.TabIndex = 19;
            this.exitButton.Text = "Exit";
            this.exitButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.youSureShow);
            // 
            // youSureMessage
            // 
            this.youSureMessage.AutoSize = true;
            this.youSureMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.youSureMessage.ForeColor = System.Drawing.Color.White;
            this.youSureMessage.Location = new System.Drawing.Point(198, 230);
            this.youSureMessage.Name = "youSureMessage";
            this.youSureMessage.Size = new System.Drawing.Size(511, 39);
            this.youSureMessage.TabIndex = 20;
            this.youSureMessage.Text = "Are You Sure You Want To Exit?";
            // 
            // Yes
            // 
            this.Yes.AutoSize = true;
            this.Yes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Yes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Yes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.Yes.ForeColor = System.Drawing.Color.Lime;
            this.Yes.Location = new System.Drawing.Point(299, 304);
            this.Yes.Name = "Yes";
            this.Yes.Size = new System.Drawing.Size(48, 27);
            this.Yes.TabIndex = 21;
            this.Yes.Text = "Yes";
            this.Yes.MouseUp += new System.Windows.Forms.MouseEventHandler(this.exitGame);
            // 
            // No
            // 
            this.No.AutoSize = true;
            this.No.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.No.Cursor = System.Windows.Forms.Cursors.Hand;
            this.No.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.No.ForeColor = System.Drawing.Color.Red;
            this.No.Location = new System.Drawing.Point(518, 304);
            this.No.Name = "No";
            this.No.Size = new System.Drawing.Size(39, 27);
            this.No.TabIndex = 22;
            this.No.Text = "No";
            this.No.MouseUp += new System.Windows.Forms.MouseEventHandler(this.returnGame);
            // 
            // pauseButton
            // 
            this.pauseButton.BackColor = System.Drawing.Color.Transparent;
            this.pauseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pauseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.pauseButton.ForeColor = System.Drawing.Color.White;
            this.pauseButton.Location = new System.Drawing.Point(835, 9);
            this.pauseButton.Name = "pauseButton";
            this.pauseButton.Size = new System.Drawing.Size(44, 48);
            this.pauseButton.TabIndex = 24;
            this.pauseButton.Text = "||";
            this.pauseButton.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.pauseButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pauseGame);
            // 
            // playButton
            // 
            this.playButton.BackColor = System.Drawing.Color.Transparent;
            this.playButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("playButton.BackgroundImage")));
            this.playButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.playButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.playButton.Location = new System.Drawing.Point(831, 9);
            this.playButton.Name = "playButton";
            this.playButton.Size = new System.Drawing.Size(48, 48);
            this.playButton.TabIndex = 25;
            this.playButton.TabStop = false;
            this.playButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.play);
            // 
            // baby
            // 
            this.baby.AutoSize = true;
            this.baby.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.baby.Cursor = System.Windows.Forms.Cursors.Hand;
            this.baby.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.baby.ForeColor = System.Drawing.Color.LightBlue;
            this.baby.Location = new System.Drawing.Point(398, 95);
            this.baby.Name = "baby";
            this.baby.Size = new System.Drawing.Size(97, 41);
            this.baby.TabIndex = 26;
            this.baby.Text = "Baby";
            this.baby.MouseUp += new System.Windows.Forms.MouseEventHandler(this.babyGame);
            // 
            // arrowUp
            // 
            this.arrowUp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("arrowUp.BackgroundImage")));
            this.arrowUp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.arrowUp.Location = new System.Drawing.Point(110, 38);
            this.arrowUp.Name = "arrowUp";
            this.arrowUp.Size = new System.Drawing.Size(71, 86);
            this.arrowUp.TabIndex = 27;
            this.arrowUp.TabStop = false;
            // 
            // arrowDown
            // 
            this.arrowDown.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("arrowDown.BackgroundImage")));
            this.arrowDown.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.arrowDown.Location = new System.Drawing.Point(110, 396);
            this.arrowDown.Name = "arrowDown";
            this.arrowDown.Size = new System.Drawing.Size(71, 86);
            this.arrowDown.TabIndex = 28;
            this.arrowDown.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(624, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "lol";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(296, 457);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 13);
            this.label3.TabIndex = 30;
            this.label3.Text = "lol";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(245, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 20);
            this.label4.TabIndex = 31;
            this.label4.Text = "lol";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(807, 457);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 46);
            this.label5.TabIndex = 32;
            this.label5.Text = "lol";
            // 
            // ball2
            // 
            this.ball2.BackColor = System.Drawing.Color.White;
            this.ball2.Location = new System.Drawing.Point(434, 239);
            this.ball2.Name = "ball2";
            this.ball2.Size = new System.Drawing.Size(20, 20);
            this.ball2.TabIndex = 33;
            this.ball2.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(417, 318);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 34;
            this.label6.Text = "Time Trial";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(928, 574);
            this.ControlBox = false;
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ball2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.baby);
            this.Controls.Add(this.playButton);
            this.Controls.Add(this.pauseButton);
            this.Controls.Add(this.No);
            this.Controls.Add(this.Yes);
            this.Controls.Add(this.youSureMessage);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.title);
            this.Controls.Add(this.menuButton);
            this.Controls.Add(this.playAgain);
            this.Controls.Add(this.impossible);
            this.Controls.Add(this.insane);
            this.Controls.Add(this.hard);
            this.Controls.Add(this.easy);
            this.Controls.Add(this.cpuLabel);
            this.Controls.Add(this.playerScore);
            this.Controls.Add(this.cpu);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.ball);
            this.Controls.Add(this.player);
            this.Controls.Add(this.borderRight);
            this.Controls.Add(this.borderBottom);
            this.Controls.Add(this.arrowUp);
            this.Controls.Add(this.arrowDown);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pong Game MOO ICT";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyIsDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.keyIsUp);
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cpu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.borderRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.borderBottom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrowUp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrowDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox player;
        private System.Windows.Forms.PictureBox ball;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox cpu;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.Label playerScore;
        private System.Windows.Forms.Label cpuLabel;
        private System.Windows.Forms.PictureBox borderRight;
        private System.Windows.Forms.PictureBox borderBottom;
        private System.Windows.Forms.Label easy;
        private System.Windows.Forms.Label hard;
        private System.Windows.Forms.Label insane;
        private System.Windows.Forms.Label impossible;
        private System.Windows.Forms.Label playAgain;
        private System.Windows.Forms.Label menuButton;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label exitButton;
        private System.Windows.Forms.Label youSureMessage;
        private System.Windows.Forms.Label Yes;
        private System.Windows.Forms.Label No;
        private System.Windows.Forms.Label pauseButton;
        private System.Windows.Forms.PictureBox playButton;
        private System.Windows.Forms.Label baby;
        private System.Windows.Forms.PictureBox arrowUp;
        private System.Windows.Forms.PictureBox arrowDown;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox ball2;
        private System.Windows.Forms.Label label6;
    }
}

