﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Pong
{
    public partial class Form1 : Form
    {
        bool goup;
        bool godown;
        bool menuOn = true;
        bool exitPong = false;
        int speed = 5;
        int ballx = 5;
        int bally = 5;
        int score = 0;
        int cpuPoint = 0;
        int choice = 0;
        int howManyPoints = 2;
        int cpuDiff = 1;
        public Form1()

        {
            InitializeComponent();
            
        }

        private void keyIsUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
            {
                goup = false;
            }
            if (e.KeyCode == Keys.Down)
            {
                godown = false;
            }
        }

        private void keyIsDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
            {
                goup = true;
            }
            if (e.KeyCode == Keys.Down)
            {
                godown = true;
            }
        }

        private void timerTick(object sender, EventArgs e)
        {
            youSureMessage.Hide();
            Yes.Hide();
            No.Hide();
            playAgain.Hide();
            menuButton.Hide();
            ball.Show();
            playButton.Hide();
            if (menuOn == false)
                {
                    exitButton.Hide();
                    pauseButton.Show();
                if (choice == 0)
                    {
                        ball.Hide();
                        pauseButton.Hide();
                        speed = 5;
                        ballx = 5;
                        bally = 5;
                        score = 0;
                        cpuPoint = 0;
                        gameTimer.Stop();
                    }
                    pauseButton.Show();
                    playerScore.Text = "" + score;
                    cpuLabel.Text = "" + cpuPoint;

                    ball.Top -= bally;
                    ball.Left -= ballx;

                    cpu.Top += speed;

                    if (score < 5)
                    {
                        if (cpu.Top < 0 || cpu.Top > 455)
                        {
                            speed = -speed;
                        }
                    }
                    else
                    {
                        if (choice == 5)
                        {
                            if (cpu.Top < 0 || cpu.Top > 455)
                            {
                            speed = -speed;
                            }
                        }
                        else
                        {
                            cpu.Top = ball.Top + cpuDiff;
                        }
                    }
                    if (choice == 5)
                    {
                        if(ball.Top > player.Bottom)
                        {
                            arrowDown.Show();
                            arrowUp.Hide();
                        } else if(ball.Bottom < player.Top)
                        {
                            arrowDown.Hide();
                            arrowUp.Show();
                        }
                        else
                        {
                            arrowUp.Hide();
                            arrowDown.Hide();
                        }
                    }
                    if (ball.Left < 0)
                    {
                        ball.Left = 434;
                        ballx = -ballx;
                        ballx -= 2;
                        cpuPoint++;
                        Play();
                    }

                    if (ball.Bounds.IntersectsWith(borderRight.Bounds))
                    {
                        ball.Left = 434;
                        ballx = -ballx;
                        ballx += 2;
                        score++;
                        Play();
                    }

                    if (ball.Top < 0 || ball.Bounds.IntersectsWith(borderBottom.Bounds))
                    {
                        bally = -bally;
                    }

                    if (ball.Bounds.IntersectsWith(player.Bounds) || ball.Bounds.IntersectsWith(cpu.Bounds))
                    {
                        ballx = -ballx;
                    }

                    if (goup == true && player.Top > 0)
                    {
                        player.Top -= 8;
                    }

                    if (godown == true && !player.Bounds.IntersectsWith(borderBottom.Bounds))
                    {
                        player.Top += 8;
                    }

                    if (score > (howManyPoints - 1))
                    {
                        playerScore.Text = "" + score;
                        gameTimer.Stop();
                        MessageBox.Show("You Win... This Time");
                        playAgain.Show();
                        menuButton.Show();
                        pauseButton.Hide();
                        playButton.Hide();
                        exitButton.Show();
                        exitButton.SetBounds(570, 344, 90, 48);
                    }

                    if (cpuPoint > (howManyPoints - 1))
                    {
                        cpuLabel.Text = "" + cpuPoint;
                        gameTimer.Stop();
                        MessageBox.Show("CPU Wins HA HA HA");
                        playAgain.Show();
                        menuButton.Show();
                        pauseButton.Hide();
                        exitButton.Show();
                        exitButton.SetBounds(570, 344, 90, 48);
                        playButton.Hide();
                    }
                }
                else
                {
                    pauseButton.Hide();
                    arrowUp.Hide();
                    arrowDown.Hide();
                    exitButton.SetBounds(823, 9, 90, 48);
                    exitButton.Show();
                }
            
        }

        private void easyGame(object sender, MouseEventArgs e)
        {
            cpu.SetBounds(897, 230, 27, 127);
            player.SetBounds(12, 186, 27, 127);
            ball.SetBounds(434, 239, 27, 26);
            cpuDiff = 40;
            choice = 1;
            speed = 5;
            ballx = 5;
            bally = 5;
            score = 0;
            cpuPoint = 0;
            howManyPoints = 10;
            easy.Hide();
            hard.Hide();
            insane.Hide();
            impossible.Hide();
            playAgain.Hide();
            menuButton.Hide();
            baby.Hide();
            title.Hide();
            playButton.Hide();
            pauseButton.Show();
            menuOn = false;
            gameTimer.Start();
        }

        private void hardGame(object sender, MouseEventArgs e)
        {
            cpu.SetBounds(897, 230, 27, 127);
            player.SetBounds(12, 186, 27, 58);
            ball.SetBounds(434, 239, 27, 26);
            howManyPoints = 15;
            cpuDiff = 30;
            speed = 5;
            ballx = 5;
            bally = 5;
            score = 0;
            cpuPoint = 0;
            choice = 2;
            menuOn = false;
            baby.Hide();
            easy.Hide();
            hard.Hide();
            insane.Hide();
            impossible.Hide();
            playAgain.Hide();
            menuButton.Hide();
            title.Hide();
            playButton.Hide();
            pauseButton.Show();
            gameTimer.Start();
        }

        private void insaneGame(object sender, MouseEventArgs e)
        {
            cpu.SetBounds(897, 230, 27, 127);
            ball.SetBounds(434, 239, 27, 26);
            player.SetBounds(12, 186, 27, 37);
            cpuDiff = 27;
            choice = 3;
            speed = 5;
            ballx = 5;
            bally = 5;
            score = 0;
            cpuPoint = 0;
            howManyPoints = 30;
            menuOn = false;
            baby.Hide();
            easy.Hide();
            hard.Hide();
            insane.Hide();
            impossible.Hide();
            playAgain.Hide();
            menuButton.Hide();
            title.Hide();
            playButton.Hide();
            pauseButton.Show();
            gameTimer.Start();
        }

        private void impossibleGame(object sender, MouseEventArgs e)
        {
            cpu.SetBounds(897, 230, 14, 200);
            player.SetBounds(12, 186, 14, 14);
            ball.SetBounds(434, 239, 5, 6);
            cpuDiff = 4;
            choice = 4;
            speed = 5;
            ballx = 5;
            bally = 5;
            score = 0;
            cpuPoint = 0;
            howManyPoints = 91;
            menuOn = false;
            easy.Hide();
            hard.Hide();
            insane.Hide();
            impossible.Hide();
            playAgain.Hide();
            menuButton.Hide();
            title.Hide();
            playButton.Hide();
            pauseButton.Show();
            gameTimer.Start();
        }

        private void resetGame(object sender, MouseEventArgs e)
        {
            speed = 5;
            ballx = 5;
            bally = 5;
            score = 0;
            cpuPoint = 0;
            cpu.SetBounds(897, 230, 27, 127);
            if (choice == 1)
            {
                player.SetBounds(12, 186, 27, 127);
            }
            else if (choice == 2)
            {
                player.SetBounds(12, 186, 27, 58);
            }
            else if (choice == 3)
            {
                player.SetBounds(12, 186, 27, 37);
            }
            else if (choice == 4)
            {
                player.SetBounds(12, 186, 27, 14);
            }
            else if (choice == 5)
            {
                player.SetBounds(12, 186, 27, 160);
                cpu.SetBounds(897, 230, 27, 80);
            }
            if(choice == 4)
            {
                ball.SetBounds(434, 239, 5, 6);
            } else if (choice < 4)
            {
                ball.SetBounds(434, 239, 27, 26);
            } else if (choice == 5)
            {
                ball.SetBounds(434, 239, 50, 51);
            }
            title.Hide();
            playButton.Hide();
            pauseButton.Show();
            gameTimer.Start();
        }

        private void menu(object sender, MouseEventArgs e)
        {
            menuOn = true;
            exitButton.SetBounds(823, 9, 90, 48);
            exitButton.Show();
            baby.Show();
            easy.Show();
            hard.Show();
            insane.Show();
            impossible.Show();
            playAgain.Hide();
            title.Show();
            menuButton.Hide();
            playButton.Hide();
            pauseButton.Hide();
        }

        private void returnGame(object sender, MouseEventArgs e)
        {
            youSureMessage.Hide();
            Yes.Hide();
            No.Hide();
        }

        private void exitGame(object sender, MouseEventArgs e)
        {
            Application.Exit();
            
        }

        private void youSureShow(object sender, MouseEventArgs e)
        {
            gameTimer.Stop();
            youSureMessage.Show();
            Yes.Show();
            No.Show();
        }

        private void play(object sender, MouseEventArgs e)
        {
            playButton.Hide();
            exitButton.Hide();
            pauseButton.Show();
            menuButton.Hide();
            gameTimer.Start();
        }

        private void pauseGame(object sender, MouseEventArgs e)
        {
            exitButton.SetBounds(570, 344, 90, 48);
            playButton.Show();
            exitButton.Show();
            pauseButton.Hide();
            menuButton.Show();
            gameTimer.Stop();
        }

        private void Play()
        {
            System.Media.SoundPlayer bounce = new System.Media.SoundPlayer(@"c:\Users\mc_awebb22\Desktop\Sounds\sound.wav");
            
        }

        private void babyGame(object sender, MouseEventArgs e)
        {
            cpu.SetBounds(897, 230, 27, 80);
            player.SetBounds(12, 186, 27, 160);
            ball.SetBounds(434, 239, 50, 51);
            cpuDiff = 50;
            choice = 5;
            speed = 3;
            ballx = 5;
            bally = 5;
            score = 0;
            cpuPoint = 0;
            howManyPoints = 10;
            baby.Hide();
            easy.Hide();
            hard.Hide();
            insane.Hide();
            impossible.Hide();
            playAgain.Hide();
            menuButton.Hide();
            title.Hide();
            playButton.Hide();
            pauseButton.Show();
            menuOn = false;
            gameTimer.Start();
        }
    }
}
