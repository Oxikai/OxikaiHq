import os
import webbrowser as wb
import datetime as Date

anythingElse = False
#availible = True

#class clear:
# def __call__(self):
#  if os.name==('ce','nt','dos'): os.system('cls')
#  elif os.name=='posix': os.system('clear')
#  else: print('\n'*120)
# def __neg__(self): self()
# def __repr__(self):
 # self();return ''

#clear=clear()

def start():
	userInfo = open("userInfo.txt", "r")
	read = userInfo.readlines()
	name = read[0].strip()
	birthdate = read[1].strip()
	birthdate = birthdate.split("/")
	birthdate.pop(2)
	birthdate = "/".join(birthdate)
	userInfo.close()
	date = Date.datetime.now()
	todayDate = "{}/{}".format(date.strftime("%m"), date.strftime("%d"))
	if(todayDate == birthdate):
		print("Happy birthday {}!".format(name))
	else:
		print ("Hello " + name.strip() + "! Nice to see you")
	Command(anythingElse)

#def checkForUsernameAval(newUsername) :
#	print ("hi")
#	path = "C:\\Users\\mc_awebb22\\source\\repos\\Alfred\\Alfred"
#	def find("{}.txt".format(newUsername), path):
#		for root, dirs, files in os.walk(path):
#			if searchName in files:
#				availible = False
#			else:
#				availible = True

def Command(anythingElse):
	if(anythingElse == False):
		userInfo = open("userInfo.txt", "r")
		name = userInfo.readline().strip()
		userInfo.close()
		print ("What would you like to do?")
	else:
		print("Anything else?")
	command = input()
	command = command.lower()
	args = command.split(" ")
	if (args[0] == "open"):
		args.pop(0)
		file = " ".join(args)
		try:
			os.startfile(file)
		except FileNotFoundError:
			print ("Sorry, I couldn't find your file")
			anythingElse = True
			Command(anythingElse)
		else:
			print ("Opening " + file + "...")
			anythingElse = True
	elif(args[0] == "settings"):
		print ("Opening your settings...")
		openSettings()
		openSettings()
	elif (args[0] == "exit"):
		answer = input("Are you sure you want to exit Alfred? -> ")
		if (answer == "yes"):
			print ("See ya later aligator")
		else:
			print ("Glad you're staying!")
			Command(anythingElse)
	elif(args[0] == "help"):
		help()
	elif(args[0] == "search"):
		siteSearch = "https://google.com/search?q="
		print ("Searching...")
		args.pop(0)
		if(args[0] == "for"):
			args.pop(0)
			siteSearch = "https://google.com/search?q="
		elif(args[0] == "youtube" and args[1] == "for"):
			args.pop(0)
			args.pop(0)
			siteSearch = "https://youtube.com/results?search_query="
		searchTerm = " ".join(args)
		try:
			wb.get("C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s").open(siteSearch + searchTerm)
			anythingElse = True
			Command(anythingElse)
		except:
			print("My search function seems to have an error, try again later")
			anythingElse = True
			Command(anythingElse)
	elif(args[0] == "what"):
		args.pop(0)
		if(args[0] == "is"):
			args.pop(0)
			if(args[0] == "my"):
				args.pop(0)
				if(args[0] == "name" or args[0] == "name?"):
					userInfo = open("userInfo.txt", "r")
					name = userInfo.readline().strip()
					userInfo.close()
					print("Your name is " + name)
				if(args[0] == "age" or args[0] == "age?"):
					userInfo = open("userInfo.txt", "r")
					read = userInfo.readlines()
					birthdate = read[1].strip()
					birthdate = birthdate.split("/")
					date = Date.datetime.now()
					if(int(date.strftime("%m")) < int(birthdate[0])):
						yearOld = (int(date.strftime("%Y")) - int(birthdate[2])) - 1
					elif(int(date.strftime("%m")) == int(birthdate[0])):
						if(int(date.strftime("%d")) < int(birthdate[1])):
							yearOld = int(date.strftime("%Y")) - int(birthdate[2]) - 1
						else:
							yearOld = int(date.strftime("%Y")) - int(birthdate[2])
					else:
						yearOld = int(date.strftime("%Y")) - int(birthdate[2])
					print(yearOld)
					anythingElse = True
					Command(anythingElse)
	elif(args[0] == "what's"):
		args.pop(0)
		if(args[0] == "my"):
			args.pop(0)
			if(args[0] == "name" or args[0] == "name?"):
				userInfo = open("userInfo.txt", "r")
				name = userInfo.readline().strip()
				userInfo.close()
				print("Your name is " + name)
			if(args[0] == "age" or args[0] == "age?"):
				userInfo = open("userInfo.txt", "r")
				read = userInfo.readlines()
				birthdate = read[1].strip()
				birthdate = birthdate.split("/")
				date = Date.datetime.now()
				if(int(date.strftime("%m")) < int(birthdate[0])):
					yearOld = (int(date.strftime("%Y")) - int(birthdate[2])) - 1
				elif(int(date.strftime("%m")) == int(birthdate[0])):
					if(int(date.strftime("%d")) < int(birthdate[1])):
						yearOld = int(date.strftime("%Y")) - int(birthdate[2]) - 1
					else:
						yearOld = int(date.strftime("%Y")) - int(birthdate[2])
				else:
					yearOld = int(date.strftime("%Y")) - int(birthdate[2])
				print(yearOld)
				anythingElse = True
				Command(anythingElse)
			else:
				args = " ".join(args)
				wb.get("C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s").open("https://google.com/search?q=what%20is%20" + args)
				anythingElse = True
				Command(anythingElse)
	elif(args[0] == "how"):
		args.pop(0)
		if(" ".join(args) == "old am i" or " ".join(args) == "old am i?"):
					userInfo = open("userInfo.txt", "r")
					read = userInfo.readlines()
					birthdate = read[1].strip()
					birthdate = birthdate.split("/")
					date = Date.datetime.now()
					if(int(date.strftime("%m")) < int(birthdate[0])):
						yearOld = (int(date.strftime("%Y")) - int(birthdate[2])) - 1
					elif(int(date.strftime("%m")) == int(birthdate[0])):
						if(int(date.strftime("%d")) < int(birthdate[1])):
							yearOld = int(date.strftime("%Y")) - int(birthdate[2]) - 1
						else:
							yearOld = int(date.strftime("%Y")) - int(birthdate[2])
					else:
						yearOld = int(date.strftime("%Y")) - int(birthdate[2])
					print(yearOld)
					anythingElse = True
					Command(anythingElse)
		else:
			args = " ".join(args)
			wb.get("C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s").open("https://google.com/search?q=how%20" + args)
			anythingElse = True
			Command(anythingElse)
	elif (args[0] == "no"):
		print("Have a nce day!")
	else:
		print ("I'm not sure what you want...")
		Command(anythingElse)

def getWorking():
	settings = "no"
	fileSearch = "yes"

def help():
	print("What would you like help with?")
	print("Suggestions:")
	print("	Commands")          #not spaces, these are tab spaces
	print("	Search")
	question = input()
	if (question.lower() == "commands"):
		print("these are some of my commands:")
		print("	search (for), this comand utilizes google to search the world wide web, you can even search youtube directly, just type \"search youtube for\" then whatever you want to search")
		print("	open, this command will let me search your computer for a file you wish to open, you can even type the file extenstion to make me more accurate")
		print("	help, this opens the help center where you can find help with Alfred-related issues")
		print("	settings, the settings feature has the ability to view and change your current settings")
	elif(question.lower() == "search"):
		print("The search comand utilizes google to search the world wide web, you can even search youtube directly, just type \"search youtube for\" then whatever you want to search")
	elif(question.lower() == "settings"):
		print("The settings feature is just what is seems, here you can view, and change your settings whenever you like")
	else:
		print("I'm not sure what you want")
	print("Would you like to continue learning?")
	hContinue = input()
	args = hContinue.split(" ")
	if (args[0] == "yes"):
		help()
	elif(args[0] == "no"):
		print ("Alrighty")
		anythingElse = True
		Command(anythingElse)
	else:
		print("I'm not sure what you mean")
		anythingElse = True
		Command(anythingElse)

def openSettings():
	userInfo = open("userInfo.txt", "r")
	setInfo = userInfo.readlines()
	userInfo.close()
	print ("* Name: " + setInfo[0].strip())
	print ("* Birthday: " + setInfo[1].strip())
	print ("* Favorite Color: " + setInfo[2].strip())
	print("Would you like to chage these settings?")
	answer = input()
	answer = answer.lower()
	if(answer == "yes"):
		userInfo = open("userInfo.txt", "w")
		print("What would you like to change?")
		answer = input('Type "name", "birthday", or "favorite color" -> ')
		answer = answer.lower()
		if (answer == "name"):
			print("What would you like your new name to be?")
			newName = input()
			userInfo.write("{}\n".format(newName))
			userInfo.write(setInfo[1])
			userInfo.write(setInfo[2])
			userInfo.close()
			anythingElse = True
			Command(anythingElse)
		elif (answer == "birthday"):
			print("When is your birthday?")
			newDate = input("*mm/dd/yyyy* -> ")
			userInfo.write(setInfo[0])
			userInfo.write("{}\n".format(newDate))
			userInfo.write(setInfo[2])
			userInfo.close()
			anythingElse = True
			Command(anythingElse)
		elif (answer == "favorite color"):
			print("What is your favorite color?")
			newColor = input()
			userInfo.write(setInfo[0])
			userInfo.write(setInfo[1])
			userInfo.write("{}\n".format(newColor))
			userInfo.close()
			anythingElse = True
			Command(anythingElse)
		else:
			print('I\'m not sure what you asked, try "name", "birthday", or "favorite color')
			userInfo.close()
			openSettings()
	elif(answer == "no"):
		print("alrighty then")
		userInfo.close()
		anythingElse = True
		Command(anythingElse)
	elif(answer == "exit"):
		print("Closing down settings")
		userinfo.close()
		anythingElse = True
		Command(anythingElse)
	else:
		print("I'm sorry, that's not one of the options, please try again")
		userInfo.close()
		openSettings()

def newUser():
	print ("Hello New User! Would you mind telling me your name?")
	userInfo = open("userInfo.txt", "w+")
	userInfo.write(input() + "\n")
	print ("Great!, How about your birthday?")
	userInfo.write(input('*mm/dd/yyyy* ') + "\n")
	print ("Cool!")
	print ("What about your favorite color?")
	userInfo.write(input() + "\n")
	userInfo.close()
	start()

#def signIn():
#	print ("****** Sign In ******")
#	searchName = input("Username -> ")
#	searchName = searchName + ".txt"
#	fileName = searchName
#	path = "C:\\Users\\mc_awebb22\\source\\repos\\Alfred\\Alfred"
#	def find(searchName, path):
#		for root, dirs, files in os.walk(path):
#			if searchName in files:
#				file = os.path.join(root, searchName)
#				if (os.path.isfile(file)):
#					passwordAtt = input("Password -> ")
#					#print (searchName)
#					userInfo = open(searchName, "r")
#					read = userInfo.readlines()
#					#print (read)
#					def password():
#						if (read[4].strip() == passwordAtt):
#							userInfo.close()
#							if(read[5].strip() == "yes"):
#								lastRem = open("lastRem.txt", "w")
#								lastRem.write(searchName)
#								lastRem.close()
#							start()
#						else:
#							print ("Wrong password, try again?")
#							answer = input()
#							if(answer == "yes"):
#								signIn()
#							else:
#								print ("Would you like to exit, or create a new profile?")
#								answer = input()
#								if (answer == "exit"):
#									print ("exiting Alfred...")
#								elif (answer ==  "new profile"):
#									newuser()
#								else:
#									print ("Invalid answer, type either \"exit\", or \"new profile\"")
#									signIn()
#					password()
#			else:
#					print ("User doesen't exist")
#					print ("Would you like to try again? Or make a new profile?")
#					answer = input()
#					if(answer == "try again"):
#						signIn()
#					elif(answer == "new profile"):
#						newUser()
#					else:
#						print ("Invalid answer, please try again")
#						signIn()
#	find(searchName, path)

#lastRem = open("lastRem.txt", "r")
#primeDir = lastRem.readline()
#primeDir.strip()
#if (primeDir == "none"):
#	signIn()
#else:
#	userInfo = open(primeDir, "r")
#	name = userInfo.readline().strip()
#	userInfo.close()
#	start()

userInfo = open("userInfo.txt", "r")
name = userInfo.readline().strip()
userInfo.close()
if (name == ""):
	newUser()
else:
	start()